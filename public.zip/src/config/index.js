export const conifgs = {
    localStorageName:"laserget_data",
    localStorageTokenName:"laserget_name_token",
    // LOCAL_BASE_URL: "http://localhost:3209/api/",
    LOCAL_BASE_URL: "http://192.168.1.76:3210/api/",
    LIVE_BASE_URL:"https://lesarjet.camp-coding.site/api/",
    localStorageUserPermissionsData :"laserjet_user_permissions_data"
}