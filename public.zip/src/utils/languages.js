export const languages = [
    {
        id:1,
        value:'ar',
        label:"العربيه"
    },
    {
        id:2,
        value:'en',
        label:"الانجليزية"
    }
]