"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { useSession } from "next-auth/react";
import { Button, Card, Radio, Select } from "antd";

import GetCartData from "@/CartAction/GetCartData";
import DeletePtoductitem from "@/CartAction/DeleteProduct";
import NewAddToCartButton from "../_commponent/NewCartButton";
import AddAddressModal from "../components/AddAddressModal";

const formatPrice = (value) =>
  new Intl.NumberFormat("ar-EG", { style: "currency", currency: "EGP" }).format(value);

export default function CheckoutPage() {
  const { data: session, status } = useSession();
  const [cart, setCart] = useState(null);
  const [paymentMethod, setPaymentMethod] = useState("");

  const [addresses, setAddresses] = useState([
    { id: 1, title: "المنزل – شارع الثورة، القاهرة" },
    { id: 2, title: "العمل – مدينة نصر، القاهرة" },
  ]);
  const [selectedAddress, setSelectedAddress] = useState(1);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [addressType, setAddressType] = useState("");
  const [governorate, setGovernorate] = useState("");
  const [newAddress, setNewAddress] = useState("");

  useEffect(() => {
    async function fetchCart() {
      const data = await GetCartData();
      setCart(data?.success ? data : { data: [] });
    }
    fetchCart();
  }, []);

  async function deleteProduct(product_id) {
    const data = await DeletePtoductitem(product_id);
    if (data.success) {
      const updatedCart = await GetCartData();
      setCart(updatedCart);
    }
  }

  const handleAddAddress = () => {
    const finalAddress = {
      id: Date.now(),
      title: `${addressType} – ${newAddress}, ${governorate}`,
      type: addressType,
      governorate,
      details: newAddress,
    };

    setAddresses([...addresses, finalAddress]);
    setIsModalOpen(false);
    setAddressType("");
    setGovernorate("");
    setNewAddress("");
  };

  if (status === "loading" || !cart) return <p className="text-center text-xl mt-10">...جاري التحميل</p>;
  if (!session)
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 text-center">
        <h1 className="text-2xl font-bold mb-4 text-gray-900">الرجاء تسجيل الدخول أولًا</h1>
        <p className="text-gray-600 mb-6">للوصول إلى سلة التسوق الخاصة بك، يجب أن تقوم بتسجيل الدخول.</p>
        <Link href="/login" className="rounded-full bg-blue-600 px-6 py-3 text-white font-semibold hover:bg-blue-700">تسجيل الدخول</Link>
      </div>
    );

  const items = cart.data || [];
  const subtotal = items.reduce((sum, item) => sum + item.sell_price * item.quantity, 0);
  const totalWithOffers = items.reduce(
    (sum, item) => sum + (item.offer?.sell_value ?? item.sell_price) * item.quantity,
    0
  );
  const totalDiscount = subtotal - totalWithOffers;

  return (
    <main dir="rtl" className="mx-auto flex flex-col justify-between max-w-6xl gap-8 px-4 py-8">
      <div className="grid grid-cols-2 gap-5">
        {/* عمود المنتجات */}
        <section className="flex-1">
          <h1 className="mb-4 text-2xl font-bold text-gray-900">سلة التسوق</h1>
          <p className="mb-6 text-sm text-gray-500">
            {items.length === 0 ? "سلة التسوق الخاصة بك فارغة." : `لديك ${items.length} منتج في السلة.`}
          </p>

          <div className="space-y-4">
            {items.map((item) => {
              const unitPrice = item.sell_price;
              const offerPrice = item.offer?.sell_value ?? null;
              const lineTotal = (offerPrice ?? unitPrice) * item.quantity;

              return (
                <div key={item.product_id} className="flex flex-col gap-4 rounded-2xl border border-gray-200 bg-white p-4 shadow-sm sm:flex-row">
                  <div className="relative h-28 w-28 flex-shrink-0 overflow-hidden rounded-xl border border-gray-100">
                    <Image src={item.images} alt={item.title} fill className="object-contain" />
                  </div>

                  <div className="flex flex-1 flex-col justify-between gap-2">
                    <div>
                      <h2 className="mb-1 text-sm font-semibold text-gray-900">{item.title}</h2>
                    </div>
                    <div className="flex flex-wrap items-end justify-between gap-3">
                      <div className="space-y-1 text-sm">
                        <div className="flex items-baseline gap-2">
                          {offerPrice && <span className="text-base font-bold text-emerald-600">{formatPrice(offerPrice)}</span>}
                          <span className={offerPrice ? "text-xs text-gray-400 line-through" : "text-base font-semibold text-gray-900"}>
                            {formatPrice(unitPrice)}
                          </span>
                        </div>
                        <p className="text-xs text-gray-500">
                          الكمية: <span className="font-semibold">{item.quantity}</span>
                        </p>
                        <p className="text-xs font-medium text-gray-900">إجمالي المنتج: {formatPrice(lineTotal)}</p>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
            {items.length === 0 && (
              <div className="rounded-2xl border border-dashed border-gray-300 bg-gray-50 p-8 text-center text-sm text-gray-500">
                لا توجد منتجات في سلتك حاليًا.
                <br />
                <Link href="/" className="mt-3 inline-block text-sm font-semibold text-blue-600 hover:underline">تصفح المنتجات</Link>
              </div>
            )}
          </div>
        </section>

        {/* عمود العنوان وطرق الدفع */}
        <div className="!space-y-4 ">
          <Card className="w-full" style={{ borderRadius: 12 }} dir="rtl" title="عنوان التسليم">
            <Radio.Group onChange={(e) => setSelectedAddress(e.target.value)} value={selectedAddress} className="w-full flex flex-col !space-y-1">
              {addresses.map((address) => (
                <Card
                  key={address.id}
                  size="small"
                  className={`cursor-pointer ${selectedAddress === address.id ? "!border-blue-600 !bg-blue-50" : "!border-gray-300"}`}
                  style={{ borderRadius: 12, borderWidth: 1.5 }}
                  onClick={() => setSelectedAddress(address.id)}
                >
                  <Radio value={address.id}>{address.title}</Radio>
                </Card>
              ))}
            </Radio.Group>

            <Button type="primary" block size="large" className="mt-4 !w-1/3 bg-blue-500 !rounded-full" onClick={() => setIsModalOpen(true)}>
              إضافة عنوان جديد
            </Button>

            <AddAddressModal
              isModalOpen={isModalOpen}
              setIsModalOpen={setIsModalOpen}
              addressType={addressType}
              setAddressType={setAddressType}
              governorate={governorate}
              setGovernorate={setGovernorate}
              newAddress={newAddress}
              setNewAddress={setNewAddress}
              handleAddAddress={handleAddAddress}
            />
          </Card>

<Card title="طريقة الدفع" className="w-full " style={{ borderRadius: 12 }}>
<Select
id="paymentMethod"
value={paymentMethod || undefined}
onChange={setPaymentMethod}
placeholder="اختر طريقة الدفع"
className="w-full"
size="large"
options={[
{ value: "credit_card", label: "محفظة" },
{ value: "miniMoney", label: "قسط" },
{ value: "cash", label: "الدفع عند الاستلام" },
]}
/>

  <div className="mt-4 space-y-2 text-sm text-gray-700">
    {paymentMethod === "cash" && (
     <Select 
     className="w-full"
      options={[
        {value : "بطاقة ائتمان ", label:"بطاقة ائتمان" },
        {value : "عند الاستلام " , label : "عند الاستلام"}
      ]}
     
     
     
     />
    )}

    {paymentMethod === "credit_card" && (
      <Select
      className="w-full"
      options={[
        
        {value : "محفظتك " , label : "محفظتك"}
      ]}
      />
    )}

    {paymentMethod === "miniMoney" && (
      <>
        <Select
        className="w-full"
          options={[
            { value: "ميني موني", label: "ميني موني" },

          ]}        />
      </>
    )}
  </div>
</Card>

          <aside className="w-full self-start rounded-2xl bg-white p-5 shadow-md flex-1">
            <h2 className="mb-4 text-lg font-bold text-gray-900">ملخص الطلب</h2>
            <div className="space-y-2 text-sm text-gray-700">
              <div className="flex items-center justify-between"><span>الإجمالي قبل الخصم</span><span>{formatPrice(subtotal)}</span></div>
              {totalDiscount > 0 && <div className="flex items-center justify-between text-emerald-600"><span>إجمالي الخصم</span><span>- {formatPrice(totalDiscount)}</span></div>}
              <div className="flex items-center justify-between border-t border-dashed border-gray-200 pt-3 text-base font-bold text-gray-900">
                <span>الإجمالي المستحق</span><span>{formatPrice(totalWithOffers)}</span>
              </div>
            </div>
            <button className="mt-5 w-full rounded-full bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-emerald-700">إتمام الشراء</button>
          </aside>
        </div>
      </div>
    </main>
  );
}
