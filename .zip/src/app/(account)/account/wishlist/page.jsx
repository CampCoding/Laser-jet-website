

import React from 'react'
import WishlistPage from '../../../wishlist/page'

const AccountWishlist = () => {
  return (
    <div>
      <WishlistPage />
    </div>
  )
}

export default AccountWishlist
