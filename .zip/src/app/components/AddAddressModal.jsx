import { Modal, Input, Select } from "antd";

const addressTypes = [
  { label: "المنزل", value: "home" },
  { label: "العمل", value: "work" },
  { label: "آخر", value: "other" },
];

const egyptGovernorates = [
  "القاهرة","الجيزة","الإسكندرية","الدقهلية","الشرقية","الغربية","القليوبية",
  "المنوفية","البحيرة","كفر الشيخ","الفيوم","بني سويف","المنيا","أسيوط","سوهاج",
  "قنا","الأقصر","أسوان","الوادي الجديد","البحر الأحمر","مطروح","الإسماعيلية",
  "السويس","بورسعيد","دمياط","شمال سيناء","جنوب سيناء",
];

export default function AddAddressModal({
  isModalOpen,
  setIsModalOpen,
  addressType,
  setAddressType,
  governorate,
  setGovernorate,
  newAddress,
  setNewAddress,
  handleAddAddress
}) {
  return (
    <Modal
      title="إضافة عنوان جديد"
      open={isModalOpen}
      onOk={handleAddAddress}
      onCancel={() => setIsModalOpen(false)}
      okText="حفظ"
      cancelText="إلغاء"
    >
      <label className="font-medium text-sm !my-2">نوع العنوان</label>
      <Select
        className="w-full !mb-4 !mt-1"
        placeholder="اختر نوع العنوان"
        value={addressType}
        onChange={setAddressType}
        options={addressTypes}
        dropdownClassName="!custom-scrollbar-dropdown"
      />

      <label className="font-medium text-sm !my-2">محافظة التوصيل</label>
      <Select
        className="w-full !mb-4 !mt-1"
        placeholder="اختر المحافظة"
        value={governorate}
        onChange={setGovernorate}
        options={egyptGovernorates.map((g) => ({ label: g, value: g }))}
        showSearch
      />

      <label className="font-medium text-sm !my-2">العنوان بالتفصيل</label>
      <Input.TextArea
        rows={2}
        placeholder="اكتب العنوان بالتفصيل"
        value={newAddress}
        onChange={(e) => setNewAddress(e.target.value)}
        className="!mt-1"
      />
    </Modal>
  );
}
