

import GetProfileDtat from '@/CallApi/GetProfileDtat';
import React from 'react'

const Account = async () => {

  return (
    <div>
        hello there
    </div>
  )
}

export default Account
