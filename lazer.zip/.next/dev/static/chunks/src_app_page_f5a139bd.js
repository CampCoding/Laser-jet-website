(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_a88e8237._.js",
  "static/chunks/src_00d67733._.js",
  "static/chunks/node_modules_swiper_a2b46751._.css"
],
    source: "dynamic"
});
