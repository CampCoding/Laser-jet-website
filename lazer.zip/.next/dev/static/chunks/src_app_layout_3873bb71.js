(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__9fc0d7ce._.css",
  "static/chunks/src_0642270d._.js",
  "static/chunks/node_modules_fa9786c0._.js"
],
    source: "dynamic"
});
